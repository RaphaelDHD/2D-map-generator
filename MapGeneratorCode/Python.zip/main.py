from cut_image import cut_image_and_save

image_path = "Beach1.png"
cut_image_and_save(image_path)
